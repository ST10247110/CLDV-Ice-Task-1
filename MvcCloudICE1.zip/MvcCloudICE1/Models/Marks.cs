﻿using System.ComponentModel.DataAnnotations;

namespace MvcStudentMarks.Models;

public class StudentMarks
{
    [Key]
    public int StudentID { get; set; }
    public string? Exam { get; set; }
    [Display(Name = "Date Written")]
    [DataType(DataType.Date)]
    public DateTime Date_Written { get; set; }
    public string? Subject { get; set; }
    public decimal Mark { get; set; }
}