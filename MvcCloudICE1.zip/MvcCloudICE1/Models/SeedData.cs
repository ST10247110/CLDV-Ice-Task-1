﻿using Microsoft.EntityFrameworkCore;
using MvcCloudICE1.Data;

namespace MvcStudentMarks.Models;

public static class SeedData
{
    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var context = new MvcCloudICE1Context(
            serviceProvider.GetRequiredService<
                DbContextOptions<MvcCloudICE1Context>>()))
        {
            // Look for any movies.
            if (context.StudentMarks.Any())
            {
                return;   // DB has been seeded
            }
            context.StudentMarks.AddRange(
                new StudentMarks
                {
                    Exam = "Paper 1",
                    Date_Written = DateTime.Parse("2023-3-13"),
                    Subject = "Physics",
                    Mark = 45.85M
                },
                new StudentMarks
                {
                    Exam = "Paper 2 ",
                    Date_Written = DateTime.Parse("2023-4-01"),
                    Subject = "Physics",
                    Mark = 60.50M
                },
                new StudentMarks
                {
                    Exam = "Creative Writing",
                    Date_Written = DateTime.Parse("2023-3-20"),
                    Subject = "English",
                    Mark = 72.00M
                }
            );
            context.SaveChanges();
        }
    }
}