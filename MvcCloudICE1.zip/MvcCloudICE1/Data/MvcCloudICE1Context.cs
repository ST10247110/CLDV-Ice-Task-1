﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MvcStudentMarks.Models;

namespace MvcCloudICE1.Data
{
    public class MvcCloudICE1Context : DbContext
    {
        public MvcCloudICE1Context (DbContextOptions<MvcCloudICE1Context> options)
            : base(options)
        {
        }

        public DbSet<MvcStudentMarks.Models.StudentMarks> StudentMarks { get; set; } = default!;
    }
}
