﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MvcCloudICE1.Data;
using MvcStudentMarks.Models;

namespace MvcCloudICE1.Controllers
{
    public class StudentMarksController : Controller
    {
        private readonly MvcCloudICE1Context _context;

        
        public StudentMarksController(MvcCloudICE1Context context)
        {
            _context = context;
        }

        // GET: StudentMarks
        public async Task<IActionResult> Index()
        {
            return View(await _context.StudentMarks.ToListAsync());
        }

        // GET: StudentMarks/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentMarks = await _context.StudentMarks
                .FirstOrDefaultAsync(m => m.StudentID == id);
            if (studentMarks == null)
            {
                return NotFound();
            }

            return View(studentMarks);
        }

        // GET: StudentMarks/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: StudentMarks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StudentID,Exam,Date_Written,Subject,Mark")] StudentMarks studentMarks)
        {
            if (ModelState.IsValid)
            {
                _context.Add(studentMarks);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(studentMarks);
        }

        // GET: StudentMarks/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentMarks = await _context.StudentMarks.FindAsync(id);
            if (studentMarks == null)
            {
                return NotFound();
            }
            return View(studentMarks);
        }

        // POST: StudentMarks/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("StudentID,Exam,Date_Written,Subject,Mark")] StudentMarks studentMarks)
        {
            if (id != studentMarks.StudentID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(studentMarks);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StudentMarksExists(studentMarks.StudentID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(studentMarks);
        }

        // GET: StudentMarks/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentMarks = await _context.StudentMarks
                .FirstOrDefaultAsync(m => m.StudentID == id);
            if (studentMarks == null)
            {
                return NotFound();
            }

            return View(studentMarks);
        }

        // POST: StudentMarks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var studentMarks = await _context.StudentMarks.FindAsync(id);
            if (studentMarks != null)
            {
                _context.StudentMarks.Remove(studentMarks);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StudentMarksExists(int id)
        {
            return _context.StudentMarks.Any(e => e.StudentID == id);
        }
    }

}
